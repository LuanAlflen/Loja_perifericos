<?php
/**
 * Created by PhpStorm.
 * User: JEFFERSON
 * Date: 16/11/2017
 * Time: 10:56
 */

require_once "Conexao.php";
require_once "Produto.php";

class CrudProdutos {

    private $conexao;
    private $produto;

    public function __construct() {
        $this->conexao = Conexao::getConexao();
    }

    public function salvar(Produto $produto){
        $sql = "INSERT INTO produtos (nome, preco, categoria) VALUES ('$produto->nome', $produto->preco, '$produto->categoria')";

        $this->conexao->exec($sql);
    }

    public function editar($produto){
        $sql = "UPDATE produtos set nome = '$produto[nome]', preco = '$produto[preco]', categoria = '$produto[categoria]', qtd_estoque = '$produto[qtd_estoque]' WHERE id = '$produto[id]'";
        $this->conexao->exec($sql);
    }

    public function excluir(int $codigo){
        $this->conexao->exec("DELETE FROM produtos WHERE codigo = $codigo");
    }
    public function getProduto(int $codigo){
        $consulta = $this->conexao->query("SELECT * FROM produtos WHERE id = $codigo");
        $produto = $consulta->fetch(PDO::FETCH_ASSOC); //SEMELHANTES JSON ENCODE E DECODE

        return new Produto($produto['nome'], $produto['preco'], $produto['categoria'], $produto['estoque']);

    }

    public function getProdutos(){
        $consulta = $this->conexao->query("SELECT * FROM produtos");
        $arrayProdutos = $consulta->fetchAll(PDO::FETCH_ASSOC);

        //Fabrica de Produtos
        $listaProdutos = [];
        foreach ($arrayProdutos as $produto){
            $listaProdutos[] = new Produto($codigo = null, $produto['nome'], $produto['preco'], $produto['categoria'], $produto['qtd_estoque']);
        }

        return $listaProdutos;

    }
}
