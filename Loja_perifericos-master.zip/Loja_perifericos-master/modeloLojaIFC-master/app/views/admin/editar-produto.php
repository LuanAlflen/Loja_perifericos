﻿<?php
require_once "../../models/CrudProdutos.php";
require_once "cabecalho.php";

$crud = new CrudProdutos();
$produto = $crud->getProduto($_GET['id']);
$codigo = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);


?>

<h2>Editar Produtos</h2>
<form action="../../controllers/controladorProduto.php?=acao=editar&id=<?= $produto->id ?>" method="post">
    <div class="form-group">
        <label for="produto">Produto:</label>
        <input value="<?= $produto->nome ?>" name="titulo" type="text" class="form-control" id="produto" aria-describedby="nome produto" placeholder="">
    </div>

    <div class="form-group">
        <label for="preco">Preco</label>
        <input value="<?= $produto->preco ?>" name="preco" type="number" step="0.01" class="form-control" id="preco" placeholder="">
    </div>

    <div class="form-group">
        <label for="estoque">Quantidade</label>
        <input value="<?= $produto->estoque ?>" name="estoque" type="number" class="form-control" id="estoque" placeholder="">
    </div>

    <div class="form-group">
        <label for="Categoria">Categoria</label>
        <select name="categoria" class="form-control" id="Categoria">
            <option><?php if ($produto->categoria == "mouse"){echo "selected";} ?></option>
            <option>Monitor</option>
            <option>Mousepad</option>
            <option>Headset</option>
            <option>Headphone</option>
            <option>Teclado</option>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Cadastrar</button>

</form>