<?php
/**
 * Created by PhpStorm.
 * User: JEFFERSON
 * Date: 09/11/2017
 * Time: 10:40
 */

require_once "Conexao.php";


class Produto {

    public $id;
    public $nome;
    public $preco;
    public $estoque;
    public $categoria;
    //estoque

    public function __construct($nome, $preco, $categoria, $qtd_estoque, $codigo = null){ //estoque
        $this->id = $codigo;
        $this->nome = $nome;
        $this->preco = $preco;
        $this->estoque = $qtd_estoque;
        $this->categoria = $categoria;

    }

    public function estaDisponivel(){
        if ($this->estoque == 0){
            return "Indisponivel";
        }else{
            return  "Disponível";

        }

    }

}
