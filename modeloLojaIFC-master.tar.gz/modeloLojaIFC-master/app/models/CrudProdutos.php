<?php
/**
 * Created by PhpStorm.
 * User: JEFFERSON
 * Date: 16/11/2017
 * Time: 10:56
 */

require_once "Conexao.php";
require_once "Produto.php";

class CrudProdutos {

    private $conexao;
    private $produto;

    public function __construct() {
        $this->conexao = Conexao::getConexao();
    }

    public function salvar(Produto $produto){
        $sql = "INSERT INTO produtos (nome, preco, categoria) VALUES ('$produto->nome', $produto->preco, '$produto->categoria')";

        $this->conexao->exec($sql);
    }

    public function editarProduto(Produto $produto){

        $this->conexao->exec("UPDATE produtos SET nome = '$produto->nome', preco = $produto->preco, qtd_estoque = $produto->estoque, categoria = '$produto->categoria'  WHERE id = $produto->id");
    }

    public function excluir(int $codigo){
        $this->conexao->exec("DELETE FROM produtos WHERE id = $codigo");
    }
    public function getProduto(int $codigo){
        $consulta = $this->conexao->query("SELECT * FROM produtos WHERE id = $codigo");
        $produto = $consulta->fetch(PDO::FETCH_ASSOC); //SEMELHANTES JSON ENCODE E DECODE

        return new Produto($produto['nome'], $produto['preco'], $produto['categoria'], $produto['qtd_estoque'], $produto['id']);

    }

    public function getProdutos(){
        $consulta = $this->conexao->query("SELECT * FROM produtos");
        $arrayProdutos = $consulta->fetchAll(PDO::FETCH_ASSOC);

        //Fabrica de Produtos
        $listaProdutos = [];
        foreach ($arrayProdutos as $produto){
            $listaProdutos[] = new Produto($produto['nome'], $produto['preco'], $produto['categoria'], $produto['qtd_estoque'], $produto['id']);
        }

        return $listaProdutos;

    }
}
