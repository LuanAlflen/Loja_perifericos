﻿<?php

    require_once __DIR__."/../../models/CrudProdutos.php";
    require_once __DIR__."/../admin/cabecalho.php";



    //require_once __DIR__."/../admin/rodape.php";

///////////////////////////não esquece////////////////////////////////////////////

    $crud = new CrudProdutos();

    $listaProdutos = $crud->getProdutos();

    ## !!ADICIONE AQUI O CABECALHO DA PAGINA

?>

<!--Barra de busca-->
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<div class="row">
    <div class="col-md-12">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="digite o nome do produto" aria-describedby="basic-addon2">
            <button class="input-group-addon" id="basic-addon2">buscar</button>
        </div>
    </div>
</div>
<br>


<table class="table table-bordered">
    <thead>
    <tr>
        <th>Id</th>
        <th>Nome</th>
        <th>Preço</th>
        <th>Estoque</th>
        <th>Categoria</th>
        <th>Ações</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach($listaProdutos as $prod): ?>

        <tr>
            <th scope="row"><?= $prod->id ?></th>
            <td> <p class="card-text"><?= $prod->nome ?></p></td>
            <td> <p class="card-text"><?= $prod->preco ?></p></td>
            <td><p class="card-text"> <?= $prod->estoque ?> </p></td>
            <td><p class="card-text"> <?= $prod->categoria ?></p></td>
        <td>
            <a href="editar-produto.php?id=<?=$prod->id ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> |
            <a href="../../controllers/controladorProduto.php?acao=excluir&codigo=<?= $prod->id ?>"><i class="fa fa-times" aria-hidden="true"></i></a>
        </td>
    </tr>
   <?php endforeach; ?>

    </tbody>
</table>

<!-- ## ADICIONE AQUI O RODAPE DA PAGINA -->